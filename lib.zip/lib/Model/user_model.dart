class UserModel {
  final String name;
  final String email;
  final String password;
  final String passwordConfirmation;
  final String deviceName;

  UserModel({
    required this.name,
    required this.email,
    required this.password,
    required this.passwordConfirmation,
    required this.deviceName,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'password': password,
      'password_confirmation': passwordConfirmation,
      'device_name': deviceName,
    };
  }
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      password: json['password'] as String? ?? '',
      passwordConfirmation: json['password_confirmation'] as String? ??"",
      deviceName: json['device_name'] as String? ?? '',
    );
  }
}